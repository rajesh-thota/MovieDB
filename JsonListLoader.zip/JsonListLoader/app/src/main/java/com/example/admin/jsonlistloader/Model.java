package com.example.admin.jsonlistloader;

import java.io.Serializable;

/**
 * Created by ADMIN on 10-04-2017.
 */
public class Model implements Serializable {

    String posterurl;
    String tittle;
    String release_rate;
    String overview;
    String popularity;
    String video;
    String Vote;
    String Adults;

    public String getPosterurl() {
        return posterurl;
    }

    public void setPosterurl(String posterurl) {
        this.posterurl = posterurl;
    }

    public String getTittle() {
        return tittle;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getVote() {
        return Vote;
    }

    public void setVote(String vote) {
        Vote = vote;
    }

    public String getAdults() {
        return Adults;
    }

    public void setAdults(String adults) {
        Adults = adults;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getRelease_rate() {
        return release_rate;
    }

    public void setRelease_rate(String release_rate) {
        this.release_rate = release_rate;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }
}
