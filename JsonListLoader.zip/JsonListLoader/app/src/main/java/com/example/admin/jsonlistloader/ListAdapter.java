package com.example.admin.jsonlistloader;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

/**
 * Created by ADMIN on 10-04-2017.
 */
public class ListAdapter extends BaseAdapter {

    ArrayList<Model> modelArray;
    Context context;
    LayoutInflater inflater;
    ImageLoader imageLoader;
    DisplayImageOptions options;
    static Boolean load=true;


    public ListAdapter(Context cx,ArrayList<Model> array) {

        modelArray=new ArrayList<>();
        modelArray=array;
        context=cx;
        inflater=(LayoutInflater)cx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        imageLoader = ImageLoader.getInstance();
        // Create configuration for ImageLoader (all options are optional)
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(cx)
                // You can pass your own memory cache implementation
                .discCacheFileNameGenerator(new HashCodeFileNameGenerator())
                .build();
        // Initialize ImageLoader with created configuration. Do it once.
        imageLoader.init(config);
        options = new DisplayImageOptions.Builder()
                .showStubImage(R.mipmap.ic_launcher)//display stub image
                .cacheInMemory()
                .cacheOnDisc()
                .displayer(new RoundedBitmapDisplayer(20))
                .build();


    }

    @Override
    public int getCount() {
        return modelArray.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;
        if(convertView==null){

            convertView=inflater.inflate(R.layout.list_item,null);
            viewHolder=new ViewHolder();
            viewHolder.imageView=(ImageView)convertView.findViewById(R.id.img);
            viewHolder.tvtitle=(TextView)convertView.findViewById(R.id.tvtitle);
            viewHolder.tvdate=(TextView)convertView.findViewById(R.id.tvreleaseddate);
            viewHolder.tvoverview=(TextView)convertView.findViewById(R.id.tvoverview);
            viewHolder.tvpopular=(TextView)convertView.findViewById(R.id.tvpopularity);

            convertView.setTag(viewHolder);

        }else{

            viewHolder=(ViewHolder)convertView.getTag();

        }


            imageLoader.displayImage("http://image.tmdb.org/t/p/w500/" + modelArray.get(position).getPosterurl(), viewHolder.imageView, options, new ImageLoadingListener() {
                @Override
                public void onLoadingStarted(String imageUri, View view) {

                }

                @Override
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

                }

                @Override
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {

                }

                @Override
                public void onLoadingCancelled(String imageUri, View view) {

                }
            }, new ImageLoadingProgressListener() {
                @Override
                public void onProgressUpdate(String imageUri, View view, int current, int total) {

                }
            });

            viewHolder.tvtitle.setText(modelArray.get(position).getTittle());
            viewHolder.tvoverview.setText(modelArray.get(position).getOverview());
            viewHolder.tvdate.setText(modelArray.get(position).getRelease_rate());
            viewHolder.tvpopular.setText(modelArray.get(position).getPopularity());

        if(position == modelArray.size() - 1 && load)
        {

            Getdata.pagecount++;
            if(MainActivity.mainActivity.connectionDetector.isConnectingToInternet()) {
            new Getdata().execute();
        }
            load=false;
        }else{

        }


        return convertView;
    }


    public class ViewHolder{

        ImageView imageView;
        TextView tvtitle,tvdate,tvoverview,tvpopular;

    }

}
