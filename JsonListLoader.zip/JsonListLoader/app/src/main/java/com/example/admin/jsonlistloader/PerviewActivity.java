package com.example.admin.jsonlistloader;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.ImageLoadingProgressListener;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PerviewActivity extends AppCompatActivity {

    ImageView imageView;
    TextView tvtitle,tvtvdate,tvpopperview,tvadults,tvvote,tvvideo,tvoverviewper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perview);


        imageView=(ImageView)findViewById(R.id.perviewimg);
        tvtitle=(TextView)findViewById(R.id.tvtitleperview);
        tvtvdate=(TextView)findViewById(R.id.tvdate);
        tvpopperview=(TextView)findViewById(R.id.tvpopperview);
        tvadults=(TextView)findViewById(R.id.tvadults);
        tvvote=(TextView)findViewById(R.id.tvvote);
        tvvideo=(TextView)findViewById(R.id.tvvideo);
        tvoverviewper=(TextView)findViewById(R.id.tvoverviewper);

        Model m= (Model) getIntent().getSerializableExtra("bean");

        ImageLoader imageLoader = ImageLoader.getInstance();
        // Create configuration for ImageLoader (all options are optional)
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(PerviewActivity.this)
                // You can pass your own memory cache implementation
                .discCacheFileNameGenerator(new HashCodeFileNameGenerator())
                .build();
        // Initialize ImageLoader with created configuration. Do it once.
        imageLoader.init(config);
        DisplayImageOptions options = new DisplayImageOptions.Builder()
                .showStubImage(R.mipmap.ic_launcher)//display stub image
                .cacheInMemory()
                .cacheOnDisc()
                .displayer(new RoundedBitmapDisplayer(20))
                .build();


        imageLoader.displayImage("http://image.tmdb.org/t/p/w500/" + m.getPosterurl(), imageView, options, new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {

            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {

            }

            @Override
            public void onLoadingCancelled(String imageUri, View view) {

            }
        }, new ImageLoadingProgressListener() {
            @Override
            public void onProgressUpdate(String imageUri, View view, int current, int total) {

            }
        });




       //imageView.setImageBitmap(getBitmapFromURL("http://image.tmdb.org/t/p/w500/"+m.getPosterurl()));
        tvtitle.setText("Tittle:" + m.getTittle());
        tvtvdate.setText("Date:" + m.getRelease_rate());
        tvadults.setText("Adults:" + m.getAdults());
        tvpopperview.setText("Popularity:" + m.getPopularity());
        tvvote.setText("Vote:" + m.getVote());
        tvvideo.setText("Adults:" + m.getVideo());
        tvoverviewper.setText("Overview:" + m.getOverview());

    }


}
