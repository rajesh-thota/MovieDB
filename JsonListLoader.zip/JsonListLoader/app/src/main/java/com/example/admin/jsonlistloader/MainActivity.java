package com.example.admin.jsonlistloader;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
     //JSONArray jArray;
    ArrayList<Model> modelArrayList=new ArrayList<>();
    ProgressBar progressBar;
    ListAdapter adapter;
    static  MainActivity mainActivity;
    ConnectionDetector connectionDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connectionDetector=new ConnectionDetector(MainActivity.this);
        mainActivity = this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle((Html.fromHtml("<font color=\"#000000\">" + getString(R.string.app_name) + "</font>")));


       StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        listView=(ListView)findViewById(R.id.list);
        progressBar=(ProgressBar)findViewById(R.id.progressbar);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

           // Toast.makeText(MainActivity.this,""+modelArrayList.get(position).getTittle(),Toast.LENGTH_SHORT).show();
                Model mod=modelArrayList.get(position);
                Intent i=new Intent(MainActivity.this,PerviewActivity.class);
                i.putExtra("bean", (Serializable) mod);
                startActivity(i);

            }
        });

        adapter=new ListAdapter(MainActivity.this,modelArrayList);
        listView.setAdapter(adapter);
        if(connectionDetector.isConnectingToInternet()) {
            new Getdata().execute();
        }else{
            Toast.makeText(MainActivity.this,"No Internet Present",Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        modelArrayList.clear();
        ListAdapter.load=true;
    }
}
