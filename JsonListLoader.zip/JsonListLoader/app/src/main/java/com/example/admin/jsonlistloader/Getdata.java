package com.example.admin.jsonlistloader;

import android.os.AsyncTask;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by ADMIN on 10-04-2017.
 */
public class Getdata extends AsyncTask<Void, ArrayList<Model>, ArrayList<Model>> {

    HttpHandler handler=new HttpHandler();
   static int pagecount=1;
   // http://api.themoviedb.org/4/list/1?api_key=d2b62f3c092dfe5e8cfa54e044dfe0c8


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        MainActivity.mainActivity.progressBar.setVisibility(View.VISIBLE);

    }

    @Override
    protected ArrayList<Model> doInBackground(Void... params) {
        // TODO Auto-generated method stub
        String st;

        try {
            st=handler.urltojson("http://api.themoviedb.org/4/list/"+pagecount+"?api_key=d2b62f3c092dfe5e8cfa54e044dfe0c8");

            if(st!=null){

                JSONObject jObject=new JSONObject(st);
                //Log.e("resulktt",""+jObject.get("status"));
              JSONArray results=jObject.getJSONArray("results");
                  for(int i=0;i<results.length();i++){

                        JSONObject jObject2=results.getJSONObject(i);
                        Model model=new Model();
                        model.setPosterurl(jObject2.getString("poster_path"));
                        model.setTittle(jObject2.getString("original_title"));
                        model.setRelease_rate(jObject2.getString("release_date"));
                        model.setPopularity(jObject2.getString("popularity"));
                        model.setOverview(jObject2.getString("overview"));
                      model.setVideo(jObject2.getString("video"));
                      model.setVideo(jObject2.getString("vote_count"));
                      model.setAdults(jObject2.getString("adult"));
                      MainActivity.mainActivity.modelArrayList.add(model);


                    }



            }else{

            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return null;
    }


    @Override
    protected void onPostExecute(ArrayList<Model> result) {
        // TODO Auto-generated method stub
        super.onPostExecute(result);

        //ArrayAdapter<String> adapter=new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, list);
        ListAdapter.load=true;
       MainActivity.mainActivity.runOnUiThread(new Runnable() {
            public void run() {
                MainActivity.mainActivity.adapter.notifyDataSetChanged();
                MainActivity.mainActivity.progressBar.setVisibility(View.GONE);
           }
        });


    }

}
